###################################################
### chunk number 1: setup
###################################################
#line 15 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
library(rjson);
library(etp)
conn <- etp.connect("http://qbridev.swmed.edu/etp/", "68BC9124A0A8BE32");


###################################################
### chunk number 2: geneinfo
###################################################
#line 29 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
gene780 <- etp.getGene(conn, entrezID=780);
gene780;


###################################################
### chunk number 3: listPlat
###################################################
#line 38 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
platforms <- etp.getPlatforms(conn);
platforms


###################################################
### chunk number 4: probeinfoID
###################################################
#line 47 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
probe <- etp.getProbe(conn, probeID=1000008);
probe


###################################################
### chunk number 5: probeinfoName
###################################################
#line 54 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
probe <- etp.getProbe(conn, platformID=1, probeName = "1007_s_at");
probe


###################################################
### chunk number 6: probeToGenes
###################################################
#line 65 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
genes <- etp.getGenesByProbe(conn, probeID=2043812);
genes <- etp.getGenesByProbe(conn, platformID=2, probeName="234562_x_at");
genes


###################################################
### chunk number 7: 
###################################################
#line 75 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
genes <- etp.getGenesByProbe(conn, probeID=2043812, authorityID=c(1,2));
genes


###################################################
### chunk number 8: geneToProbes
###################################################
#line 86 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
probes <- etp.getProbesByGene(conn, entrezID=780);
probes


###################################################
### chunk number 9: 
###################################################
#line 93 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
probes <- etp.getProbesByGene(conn, entrezID=780, authorityID=2, platformID=1)$probes;
probes


###################################################
### chunk number 10: 
###################################################
#line 102 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
etp.getProbesByGene(conn, 57188)$probes;


###################################################
### chunk number 11: 
###################################################
#line 108 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/etp/inst/doc/ETP-Documentation.Rnw"
etp.getProbesByGene(conn, 57188)$probes[6,];


