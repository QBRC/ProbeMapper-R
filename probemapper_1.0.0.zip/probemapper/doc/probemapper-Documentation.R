###################################################
### chunk number 1: setup
###################################################
#line 17 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
library(probemapper)
conn <- pm.connect("http://qbrc.swmed.edu/ProbeMapper/");


###################################################
### chunk number 2: geneinfo
###################################################
#line 30 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
gene780 <- pm.getGene(conn, entrezID=780);
gene780;


###################################################
### chunk number 3: listPlat
###################################################
#line 39 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
platforms <- pm.getPlatforms(conn);
platforms


###################################################
### chunk number 4: probeinfoID
###################################################
#line 48 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
probe <- pm.getProbe(conn, probeID=1000008);
probe


###################################################
### chunk number 5: probeinfoName
###################################################
#line 55 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
probe <- pm.getProbe(conn, platformID=1, probeName = "1007_s_at");
probe


###################################################
### chunk number 6: probeToGenes
###################################################
#line 66 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
genes <- pm.getGenesByProbe(conn, probeID=2043812);
genes <- pm.getGenesByProbe(conn, platformID=2, probeName="234562_x_at");
genes


###################################################
### chunk number 7: 
###################################################
#line 76 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
genes <- pm.getGenesByProbe(conn, probeID=2043812, authorityID=c(1,2));
genes


###################################################
### chunk number 8: geneToProbes
###################################################
#line 87 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
probes <- pm.getProbesByGene(conn, entrezID=780);
probes


###################################################
### chunk number 9: 
###################################################
#line 94 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
probes <- pm.getProbesByGene(conn, entrezID=780, authorityID=2, platformID=1)$probes;
probes


###################################################
### chunk number 10: 
###################################################
#line 103 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
pm.getProbesByGene(conn, 57188)$probes;


###################################################
### chunk number 11: 
###################################################
#line 109 "C:/Users/jeffreya/Documents/UTSW/ProbeAlignment/ETP-R-Package/probemapper/inst/doc/probemapper-Documentation.Rnw"
pm.getProbesByGene(conn, 57188)$probes[6,];


